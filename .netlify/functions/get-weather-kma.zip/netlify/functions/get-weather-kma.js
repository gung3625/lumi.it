// netlify/functions/get-weather-kma.js
var https = require("https");
function latLonToGrid(lat, lon) {
  const RE = 6371.00877;
  const GRID = 5;
  const SLAT1 = 30;
  const SLAT2 = 60;
  const OLON = 126;
  const OLAT = 38;
  const XO = 43;
  const YO = 136;
  const DEGRAD = Math.PI / 180;
  const re = RE / GRID;
  const slat1 = SLAT1 * DEGRAD;
  const slat2 = SLAT2 * DEGRAD;
  const olon = OLON * DEGRAD;
  const olat = OLAT * DEGRAD;
  let sn = Math.tan(Math.PI * 0.25 + slat2 * 0.5) / Math.tan(Math.PI * 0.25 + slat1 * 0.5);
  sn = Math.log(Math.cos(slat1) / Math.cos(slat2)) / Math.log(sn);
  let sf = Math.tan(Math.PI * 0.25 + slat1 * 0.5);
  sf = Math.pow(sf, sn) * Math.cos(slat1) / sn;
  let ro = Math.tan(Math.PI * 0.25 + olat * 0.5);
  ro = re * sf / Math.pow(ro, sn);
  let ra = Math.tan(Math.PI * 0.25 + lat * DEGRAD * 0.5);
  ra = re * sf / Math.pow(ra, sn);
  let theta = lon * DEGRAD - olon;
  if (theta > Math.PI) theta -= 2 * Math.PI;
  if (theta < -Math.PI) theta += 2 * Math.PI;
  theta *= sn;
  const x = Math.floor(ra * Math.sin(theta) + XO + 0.5);
  const y = Math.floor(ro - ra * Math.cos(theta) + YO + 0.5);
  return { nx: x, ny: y };
}
var SIDO_GRID = {
  "\uC11C\uC6B8": { nx: 60, ny: 127 },
  "\uBD80\uC0B0": { nx: 98, ny: 76 },
  "\uB300\uAD6C": { nx: 89, ny: 90 },
  "\uC778\uCC9C": { nx: 55, ny: 124 },
  "\uAD11\uC8FC": { nx: 58, ny: 74 },
  "\uB300\uC804": { nx: 67, ny: 100 },
  "\uC6B8\uC0B0": { nx: 102, ny: 84 },
  "\uC138\uC885": { nx: 66, ny: 103 },
  "\uACBD\uAE30": { nx: 60, ny: 120 },
  "\uAC15\uC6D0": { nx: 73, ny: 134 },
  "\uCDA9\uBD81": { nx: 69, ny: 107 },
  "\uCDA9\uB0A8": { nx: 68, ny: 100 },
  "\uC804\uBD81": { nx: 63, ny: 89 },
  "\uC804\uB0A8": { nx: 51, ny: 67 },
  "\uACBD\uBD81": { nx: 91, ny: 106 },
  "\uACBD\uB0A8": { nx: 91, ny: 77 },
  "\uC81C\uC8FC": { nx: 52, ny: 38 }
};
function getPtyState(pty) {
  const v = parseInt(pty);
  if (v === 1) return "rain";
  if (v === 2) return "rain";
  if (v === 3) return "snow";
  if (v === 4) return "rain";
  return "clear";
}
function getBaseDateTime() {
  const now = /* @__PURE__ */ new Date();
  const kst = new Date(now.getTime() + 9 * 60 * 60 * 1e3);
  const mm = kst.getUTCMinutes();
  let base = new Date(kst);
  if (mm < 40) {
    base.setUTCHours(base.getUTCHours() - 1);
  }
  base.setUTCMinutes(30);
  base.setUTCSeconds(0);
  const baseDate = base.toISOString().slice(0, 10).replace(/-/g, "");
  const hh = String(base.getUTCHours()).padStart(2, "0");
  const baseTime = `${hh}30`;
  return { baseDate, baseTime };
}
function httpsGet(url) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, (res) => {
      let data = "";
      res.on("data", (chunk) => {
        data += chunk;
      });
      res.on("end", () => resolve({ status: res.statusCode, body: data }));
    });
    req.on("error", reject);
    req.setTimeout(8e3, () => {
      req.destroy(new Error("timeout"));
    });
  });
}
exports.handler = async (event) => {
  const corsHeaders = { "Content-Type": "application/json" };
  const serviceKey = process.env.PUBLIC_DATA_API_KEY;
  if (!serviceKey) {
    return { statusCode: 500, headers: corsHeaders, body: JSON.stringify({ error: "API \uD0A4 \uC5C6\uC74C" }) };
  }
  const params = event.queryStringParameters || {};
  let nx, ny, locationName;
  if (params.lat && params.lon) {
    const grid = latLonToGrid(parseFloat(params.lat), parseFloat(params.lon));
    nx = grid.nx;
    ny = grid.ny;
    locationName = params.name || "\uD604\uC7AC \uC704\uCE58";
  } else {
    const sido = params.sido || "\uC11C\uC6B8";
    const grid = SIDO_GRID[sido] || SIDO_GRID["\uC11C\uC6B8"];
    nx = grid.nx;
    ny = grid.ny;
    locationName = sido;
  }
  const { baseDate, baseTime } = getBaseDateTime();
  try {
    const url = `https://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getUltraSrtNcst?serviceKey=${serviceKey}&numOfRows=10&pageNo=1&dataType=JSON&base_date=${baseDate}&base_time=${baseTime}&nx=${nx}&ny=${ny}`;
    const result = await httpsGet(url);
    if (result.status !== 200) throw new Error("HTTP " + result.status);
    const data = JSON.parse(result.body);
    const header = data?.response?.header;
    if (header?.resultCode !== "00") throw new Error("\uAE30\uC0C1\uCCAD \uC624\uB958: " + header?.resultMsg);
    const items = data?.response?.body?.items?.item || [];
    const obs = {};
    items.forEach((item) => {
      obs[item.category] = item.obsrValue;
    });
    const temp = obs["T1H"] !== void 0 ? Math.round(parseFloat(obs["T1H"])) : null;
    const pty = obs["PTY"] || "0";
    const humidity = obs["REH"] || null;
    const windSpeed = obs["WSD"] || null;
    const state = getPtyState(pty);
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        source: "kma",
        locationName,
        temperature: temp,
        state,
        pty: parseInt(pty),
        humidity: humidity ? parseInt(humidity) : null,
        windSpeed: windSpeed ? parseFloat(windSpeed) : null,
        baseDate,
        baseTime,
        nx,
        ny
      })
    };
  } catch (e) {
    console.error("get-weather-kma error:", e.message);
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ error: e.message, source: "kma_error" })
    };
  }
};
