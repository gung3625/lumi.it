// netlify/functions/send-kakao.js
var crypto = require("crypto");
var API_KEY = process.env.SOLAPI_API_KEY;
var API_SECRET = process.env.SOLAPI_API_SECRET;
var CHANNEL_ID = process.env.SOLAPI_CHANNEL_ID || "lumi_it";
var TEMPLATES = {
  welcome: { id: "KA01TP260322191640813tM8YzoqdCss", code: "HMttBoUZVq" },
  // 회원가입 환영 (승인)
  upload: { id: "KA01TP260322191753216QJdWJqLkCrZ", code: "5XY1oOgtXW" },
  // 업로드 알림 (승인)
  schedule: { id: "KA01TP260322191942267zoXVvaI7xav", code: "1EQHbXgF4t" }
  // 데일리 스케줄 (검수중)
};
function getAuthHeader() {
  const date = (/* @__PURE__ */ new Date()).toISOString();
  const salt = Math.random().toString(36).substring(2, 12);
  const signature = crypto.createHmac("sha256", API_SECRET).update(date + salt).digest("hex");
  return `HMAC-SHA256 apiKey=${API_KEY}, date=${date}, salt=${salt}, signature=${signature}`;
}
async function sendAlimtalk(to, templateCode, variables) {
  const url = "https://api.solapi.com/messages/v4/send";
  const kakaoOptions = {
    pfId: CHANNEL_ID,
    templateId: templateCode.id,
    variables
  };
  const body = {
    message: {
      to,
      from: CHANNEL_ID,
      type: "ATA",
      kakaoOptions
    }
  };
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": getAuthHeader()
    },
    body: JSON.stringify(body)
  });
  const data = await res.json();
  console.log("[lumi] \uC54C\uB9BC\uD1A1 \uBC1C\uC1A1 \uACB0\uACFC:", JSON.stringify(data));
  return data;
}
exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method Not Allowed" }) };
  }
  const secret = event.headers["x-lumi-secret"];
  if (secret !== process.env.LUMI_SECRET) {
    return { statusCode: 401, body: JSON.stringify({ error: "\uC778\uC99D \uC2E4\uD328" }) };
  }
  let body;
  try {
    body = JSON.parse(event.body);
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: "Bad Request" }) };
  }
  const { type, to, variables } = body;
  if (!type || !to) {
    return { statusCode: 400, body: JSON.stringify({ error: "type, to \uD544\uC218" }) };
  }
  const template = TEMPLATES[type];
  if (!template) {
    return { statusCode: 400, body: JSON.stringify({ error: "\uC54C \uC218 \uC5C6\uB294 \uD15C\uD50C\uB9BF \uD0C0\uC785" }) };
  }
  try {
    const result = await sendAlimtalk(to, template, variables || {});
    return {
      statusCode: 200,
      body: JSON.stringify({ success: true, result })
    };
  } catch (e) {
    console.error("[lumi] \uC54C\uB9BC\uD1A1 \uBC1C\uC1A1 \uC624\uB958:", e.message);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "\uBC1C\uC1A1 \uC2E4\uD328", message: e.message })
    };
  }
};
