// netlify/functions/get-air-quality.js
var https = require("https");
var SIDO_MAP = {
  "\uC11C\uC6B8": "\uC11C\uC6B8",
  "\uBD80\uC0B0": "\uBD80\uC0B0",
  "\uB300\uAD6C": "\uB300\uAD6C",
  "\uC778\uCC9C": "\uC778\uCC9C",
  "\uAD11\uC8FC": "\uAD11\uC8FC",
  "\uB300\uC804": "\uB300\uC804",
  "\uC6B8\uC0B0": "\uC6B8\uC0B0",
  "\uACBD\uAE30": "\uACBD\uAE30",
  "\uAC15\uC6D0": "\uAC15\uC6D0",
  "\uCDA9\uBD81": "\uCDA9\uBD81",
  "\uCDA9\uB0A8": "\uCDA9\uB0A8",
  "\uC804\uBD81": "\uC804\uBD81",
  "\uC804\uB0A8": "\uC804\uB0A8",
  "\uACBD\uBD81": "\uACBD\uBD81",
  "\uACBD\uB0A8": "\uACBD\uB0A8",
  "\uC81C\uC8FC": "\uC81C\uC8FC",
  "\uC138\uC885": "\uC138\uC885"
};
function getPm10Grade(value) {
  if (value === null || value === void 0 || value === "-") return { grade: "\uC54C\uC218\uC5C6\uC74C", color: "#999", emoji: "\u2753" };
  const v = parseInt(value);
  if (v <= 30) return { grade: "\uC88B\uC74C", color: "#4CAF50", emoji: "\u{1F60A}" };
  if (v <= 80) return { grade: "\uBCF4\uD1B5", color: "#2196F3", emoji: "\u{1F642}" };
  if (v <= 150) return { grade: "\uB098\uC068", color: "#FF9800", emoji: "\u{1F637}" };
  return { grade: "\uB9E4\uC6B0\uB098\uC068", color: "#F44336", emoji: "\u{1F6A8}" };
}
function getPm25Grade(value) {
  if (value === null || value === void 0 || value === "-") return { grade: "\uC54C\uC218\uC5C6\uC74C", color: "#999", emoji: "\u2753" };
  const v = parseInt(value);
  if (v <= 15) return { grade: "\uC88B\uC74C", color: "#4CAF50", emoji: "\u{1F60A}" };
  if (v <= 35) return { grade: "\uBCF4\uD1B5", color: "#2196F3", emoji: "\u{1F642}" };
  if (v <= 75) return { grade: "\uB098\uC068", color: "#FF9800", emoji: "\u{1F637}" };
  return { grade: "\uB9E4\uC6B0\uB098\uC068", color: "#F44336", emoji: "\u{1F6A8}" };
}
function httpsGet(url) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, (res) => {
      let data = "";
      res.on("data", (chunk) => {
        data += chunk;
      });
      res.on("end", () => resolve({ status: res.statusCode, body: data }));
    });
    req.on("error", reject);
    req.setTimeout(8e3, () => {
      req.destroy(new Error("timeout"));
    });
  });
}
exports.handler = async (event) => {
  const corsHeaders = { "Content-Type": "application/json" };
  const sido = event.queryStringParameters?.sido || "\uC11C\uC6B8";
  const sidoName = SIDO_MAP[sido] || "\uC11C\uC6B8";
  const serviceKey = process.env.PUBLIC_DATA_API_KEY;
  if (!serviceKey) {
    return { statusCode: 500, headers: corsHeaders, body: JSON.stringify({ error: "API \uD0A4 \uC5C6\uC74C" }) };
  }
  try {
    const url = `https://apis.data.go.kr/B552584/ArpltnInforInqireSvc/getCtprvnRltmMesureDnsty?serviceKey=${encodeURIComponent(serviceKey)}&returnType=json&numOfRows=1&pageNo=1&sidoName=${encodeURIComponent(sidoName)}&ver=1.0`;
    const result = await httpsGet(url);
    if (result.status !== 200) {
      throw new Error("API \uD638\uCD9C \uC2E4\uD328: " + result.status);
    }
    const data = JSON.parse(result.body);
    const items = data?.response?.body?.items;
    if (!items || items.length === 0) {
      throw new Error("\uB370\uC774\uD130 \uC5C6\uC74C");
    }
    const item = items[0];
    const pm10Value = item.pm10Value;
    const pm25Value = item.pm25Value;
    const pm10Grade = getPm10Grade(pm10Value);
    const pm25Grade = getPm25Grade(pm25Value);
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        sido: sidoName,
        pm10: { value: pm10Value, ...pm10Grade },
        pm25: { value: pm25Value, ...pm25Grade },
        dataTime: item.dataTime || ""
      })
    };
  } catch (e) {
    console.error("get-air-quality error:", e.message);
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        sido: sidoName,
        pm10: { value: "-", grade: "\uC54C\uC218\uC5C6\uC74C", color: "#999", emoji: "\u2753" },
        pm25: { value: "-", grade: "\uC54C\uC218\uC5C6\uC74C", color: "#999", emoji: "\u2753" },
        error: e.message
      })
    };
  }
};
