// netlify/functions/get-best-time.js
var BEST_TIMES = {
  cafe: {
    slots: [
      { time: "07:30", reason: "\uCD9C\uADFC \uC804 \uBAA8\uB2DD\uCEE4\uD53C \uD0D0\uC0C9 \uD53C\uD06C" },
      { time: "12:00", reason: "\uC810\uC2EC\uC2DC\uAC04 \uCE74\uD398 \uAC80\uC0C9 \uC9D1\uC911" },
      { time: "19:30", reason: "\uD1F4\uADFC \uD6C4 \uC800\uB141 \uCE74\uD398 \uD0D0\uBC29" }
    ],
    tip: "\uC8FC\uB9D0\uC740 10\uC2DC~12\uC2DC\uAC00 \uAC00\uC7A5 \uB192\uC544\uC694."
  },
  food: {
    slots: [
      { time: "11:00", reason: "\uC810\uC2EC \uBA54\uB274 \uD0D0\uC0C9 \uC2DC\uC791" },
      { time: "17:30", reason: "\uC800\uB141 \uC2DD\uB2F9 \uAC80\uC0C9 \uD53C\uD06C" },
      { time: "20:00", reason: "\uC57C\uC2DD \uBC0F \uB2E4\uC74C\uB0A0 \uACC4\uD68D" }
    ],
    tip: "\uC74C\uC2DD \uC0AC\uC9C4\uC740 \uBC1D\uC740 \uB0AE \uC2DC\uAC04\uB300 \uC5C5\uB85C\uB4DC\uAC00 \uBC18\uC751\uC774 \uC88B\uC544\uC694."
  },
  beauty: {
    slots: [
      { time: "11:00", reason: "\uC624\uC804 \uC5EC\uC720 \uC2DC\uAC04 \uBDF0\uD2F0 \uD0D0\uC0C9" },
      { time: "19:00", reason: "\uD1F4\uADFC \uD6C4 \uC608\uC57D \uBB38\uC758 \uC9D1\uC911" },
      { time: "21:00", reason: "\uBC24 \uC2DC\uAC04 \uBDF0\uD2F0 \uCF58\uD150\uCE20 \uC18C\uBE44 \uD53C\uD06C" }
    ],
    tip: "\uD654\uC694\uC77C~\uBAA9\uC694\uC77C \uC800\uB141 \uC608\uC57D \uBB38\uC758\uAC00 \uAC00\uC7A5 \uB9CE\uC544\uC694."
  },
  other: {
    slots: [
      { time: "09:00", reason: "\uC624\uC804 \uD65C\uB3D9 \uC2DC\uC791 \uC2DC\uAC04" },
      { time: "12:30", reason: "\uC810\uC2EC\uC2DC\uAC04 SNS \uD0D0\uC0C9" },
      { time: "19:00", reason: "\uC800\uB141 \uC5EC\uAC00 \uC2DC\uAC04" }
    ],
    tip: "\uAFB8\uC900\uD55C \uC5C5\uB85C\uB4DC \uC8FC\uAE30\uAC00 \uC54C\uACE0\uB9AC\uC998\uC5D0 \uAC00\uC7A5 \uC720\uB9AC\uD574\uC694."
  }
};
function getTodayBestSlot(category) {
  const data = BEST_TIMES[category] || BEST_TIMES.other;
  const day = (/* @__PURE__ */ new Date()).getDay();
  let slotIndex = 0;
  if (day === 0 || day === 6) slotIndex = 1;
  else if (day >= 2 && day <= 4) slotIndex = 2;
  return {
    time: data.slots[slotIndex].time,
    reason: data.slots[slotIndex].reason,
    tip: data.tip,
    allSlots: data.slots
  };
}
exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
  }
  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: "\uC798\uBABB\uB41C \uC694\uCCAD" }) };
  }
  const { category } = body;
  const cat = category || "other";
  const result = getTodayBestSlot(cat);
  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      category: cat,
      bestTime: result.time,
      reason: result.reason,
      tip: result.tip,
      allSlots: result.allSlots
    })
  };
};
module.exports.getTodayBestSlot = getTodayBestSlot;
module.exports.BEST_TIMES = BEST_TIMES;
